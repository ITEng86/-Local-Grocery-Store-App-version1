from pathlib import Path
root=Path(__file__).parent
html=(root/'www/index.html').read_text()
html=html.replace('<link rel="stylesheet" href="style.css">','<style>'+(root/'www/style.css').read_text()+'</style>')
html=html.replace('<script src="app.js"></script>','<script>'+(root/'www/app.js').read_text().replace('</script','<\\/script')+'</script>')
(root/'Bottega-Preview.html').write_text(html)
(root/'android/assets/app.html').write_text(html)
(root/'ios/Bottega/app.html').write_text(html)
print('Built standalone browser preview and native web assets')
