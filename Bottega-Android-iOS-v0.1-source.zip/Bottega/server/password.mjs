import {hashPassword} from './server.mjs';
let input='';for await(const chunk of process.stdin)input+=chunk;
if(input.trim().length<12)throw Error('Use a password of at least 12 characters.');
console.log(hashPassword(input.trim()));
