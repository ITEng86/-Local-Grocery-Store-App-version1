# Bottega · v0.1 prototype

اپ فروشگاه محلی با رابط انگلیسی و ایتالیایی، بدون هوش مصنوعی و بدون پرداخت آنلاین.

## شروع سریع

فایل Bottega-Preview.html را در مرورگر باز کنید. محصولات و قیمت‌ها نمونه‌اند. با EN/IT زبان را عوض کنید. از Store → Manage products محصول و عکس اضافه کنید. چت نمونه فقط روی همان دستگاه ذخیره می‌شود؛ برای پاسخ دستی فروشنده به Store → Shop inbox بروید. فهرست خرید سفارش نیست.

APK همراه، نسخهٔ آزمایشی اندروید است و با کلید توسعه امضا شده؛ برای انتشار فروشگاهی آماده نیست. روی دستگاه واقعی تست نشده است. iOS شامل کد و تنظیمات پروژه است، نه فایل نصب امضاشده.

## Live server (Node.js 24+)

No runtime npm dependencies. SQLite persists products, shop details and chat messages. Admin access is password protected; guest conversations use separate bearer tokens. Tokens are stored hashed. Guest conversations expire and are deleted after 30 days, with hourly cleanup; customers can delete their own conversation earlier. Admin sessions expire after eight hours.

1. Generate a password hash using `node server/password.mjs`. Paste a strong password (12+ characters), then send EOF (Ctrl-D). Put the resulting hash in ADMIN_PASSWORD_HASH in your server environment. Do not place the password/hash in client code or commit it.
2. Run `node server/server.mjs`. Defaults: 127.0.0.1:8787 and data/bottega.sqlite. Set HOST/PORT/DB_PATH as needed. Production starts with an empty catalogue; SEED_DEMO=1 seeds sample products only on first database creation.
3. Place behind an HTTPS reverse proxy. Persist and back up the data directory. Dockerfile is included; mount a persistent volume at /data and provide ADMIN_PASSWORD_HASH.
4. Open the server URL in a browser; Store → Manage products prompts for the admin password. Fill the shop information and English/Italian privacy notices before enabling customer chat.
5. In mobile app: Store → Connection settings → enter your HTTPS server origin. Built-in native origins are allowed by CORS. Extra trusted browser origins may be set in ALLOWED_ORIGINS (comma separated).

No server has been deployed. Hosting and store accounts may have costs; there are no AI/API model charges. Chat is direct human messaging, with foreground polling every four seconds. There are no push notifications, automatic replies or automatic translation. A closed app receives updates when reopened. Staff type replies themselves in English or Italian. Missing ingredients/allergens must be supplied from actual labels, not inferred. Product photos remain in the database. The local list is not a reservation or an order.

## Android

Sources are in android/. Import as a Gradle project in Android Studio with Android SDK 36 and JDK 17; Gradle 8.13 is compatible with the declared Android plugin. Choose your own package id and production signing credentials before release. The included APK was compiled using Android SDK tools, ECJ and D8 and its signature was verified. No emulator/device QA has been performed. Keep the device's Android System WebView up to date.

## iOS

Requires macOS, Xcode and Apple signing. The SwiftUI/WKWebView wrapper and bundled app.html are in ios/. Install XcodeGen on your Mac, run `xcodegen generate` from ios/, open Bottega.xcodeproj, choose your signing team and run on a simulator/device. iOS code has not been compiled or device tested here. Add app icons, finalize your bundle identifier, verify image upload/local storage/HTTPS API calls on device, and complete store disclosures before submission. Publication is not included or guaranteed.

## Development and verification

Edit www/app.js and www/style.css, then run `python3 build-preview.py` to refresh preview and native assets. Run `npm ci && npm test`. Tests exercise staff authorization, privacy notice gating, isolation between customers, seller replies, deletion, invalid products, language switching, local list, demo chat and product editing. These are functional DOM/API tests, not device or visual QA.

Bottega is a placeholder name. Replace it, demo products, prices and policies with the real shop's information. Final Italian legal/privacy and app-store requirements have not been reviewed as part of this prototype. Don't submit placeholder notices as real policies.
