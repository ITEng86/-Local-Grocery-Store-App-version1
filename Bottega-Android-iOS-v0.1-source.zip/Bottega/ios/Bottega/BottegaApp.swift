import SwiftUI
import WebKit
@main struct BottegaApp: App { var body: some Scene { WindowGroup { MarketView().background(Color(red:0.97,green:0.97,blue:0.94)) } } }
struct MarketView: UIViewRepresentable {
 func makeCoordinator() -> Coordinator { Coordinator() }
 func makeUIView(context: Context) -> WKWebView {
  let configuration = WKWebViewConfiguration()
  configuration.setURLSchemeHandler(context.coordinator, forURLScheme: "bottega")
  let web = WKWebView(frame: .zero, configuration: configuration)
  web.uiDelegate = context.coordinator
  web.navigationDelegate = context.coordinator
  web.isOpaque = false
  web.load(URLRequest(url: URL(string:"bottega://localhost/app.html")!))
  return web
 }
 func updateUIView(_ uiView: WKWebView, context: Context) {}
 class Coordinator: NSObject, WKURLSchemeHandler, WKUIDelegate, WKNavigationDelegate {
  func webView(_ webView: WKWebView, start urlSchemeTask: WKURLSchemeTask) {
   guard urlSchemeTask.request.url?.path == "/app.html",let url = Bundle.main.url(forResource:"app",withExtension:"html"),let data = try? Data(contentsOf:url) else {urlSchemeTask.didFailWithError(URLError(.fileDoesNotExist));return}
   urlSchemeTask.didReceive(URLResponse(url:urlSchemeTask.request.url!,mimeType:"text/html",expectedContentLength:data.count,textEncodingName:"utf-8"))
   urlSchemeTask.didReceive(data);urlSchemeTask.didFinish()
  }
  func webView(_ webView: WKWebView, stop urlSchemeTask: WKURLSchemeTask) {}
  func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy)->Void) {
   guard let url = navigationAction.request.url else { decisionHandler(.cancel);return }
   if url.scheme == "bottega" { decisionHandler(.allow) } else { if url.scheme == "https" { UIApplication.shared.open(url) };decisionHandler(.cancel) }
  }
  func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool)->Void) {
   let alert = UIAlertController(title:"Bottega",message:message,preferredStyle:.alert)
   alert.addAction(UIAlertAction(title:"Cancel",style:.cancel){_ in completionHandler(false)})
   alert.addAction(UIAlertAction(title:"OK",style:.default){_ in completionHandler(true)})
   guard let root = webView.window?.rootViewController else {completionHandler(false);return}
   root.present(alert,animated:true)
  }
 }
}
